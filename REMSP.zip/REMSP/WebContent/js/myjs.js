var generatedOtp = "";


$("#registrationButton").click(function() {

	var name = $("#firstName").val();
	var email = $("#email").val();
	var phone = $("#phone").val();
	var birthDate = $("#birthDate").val();	
	var address = $("#text").val();
	//var gender = $('input[name=gender]:checked').val();
	
	if(name == "" && email == "" && phone == "" && birthDate == ""
		&& address == "") {
		
		alert("Please fill the form carefully");
		return false;
	}
	
		else {
		
		var rand = null;
		
		for(var i = 0; i < 6; i++)
			rand = (rand * 10) + (Math.floor(Math.random() * 9 + 1));
		
		generatedOtp = rand; 
		
		$("#loaderImage").show();
		
		$.ajax({
			
			url: "AjaxServlet",
			data: {
				action: "sendRegistrationOTPEmail",
				email: email,
				name: name,
				otp: rand
			},
			
			error: function(data) {
				$("#loaderImage").hide();
				alert("Error: " + data);
			},
			
			success: function(data) {
				$("#loaderImage").hide();
				console.log("success");
				console.log(data);
				
				$('#registrationOtpModal').modal('show');
				
			}
		});
	}
});

$("#registrationButtonModal").click(function() {
	
	console.log("Hell");
	
	var otp = $("#registrationOtpModalInput").val();
	
	alert("Received");
	console.log(generatedOtp);
	
	if(otp == generatedOtp) {
		alert("Success");
	
	}
		
	else {
		alert("Failure");
	}
	
});
		