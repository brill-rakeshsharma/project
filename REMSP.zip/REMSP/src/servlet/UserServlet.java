package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import bean.UserBean;
import dao.UserDAO;

@WebServlet("/UserServlet")
public class UserServlet extends HttpServlet {
	
	protected void service(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String page = request.getParameter("pageType");
		
		if(page.equalsIgnoreCase("loginpage"))
		{
			String uname = request.getParameter("username");
			String pass = request.getParameter("password");
			
			System.out.println("Username is: "+uname);
			System.out.println("Password is: "+pass);
			
			UserBean user = new UserDAO().login(uname);
			
			if(user != null)
			{
				System.out.println("Correct login..");
				response.sendRedirect("home.jsp");
				
			}
			
			else{
				System.out.println("Incorrect login..");
				response.sendRedirect("index.jsp");
			}
		}
		else if(page.equalsIgnoreCase("registrationpage"))
		{
			String name = request.getParameter("name");
			String email = request.getParameter("email");
			String phone = request.getParameter("phone");
			String dob = request.getParameter("date");
			String address = request.getParameter("address");
			String gender = request.getParameter("gender");
			
			System.out.println("Name is: "+name);
			System.out.println("Email is: "+email);
			System.out.println("phone is: "+phone);
			System.out.println("DOB is: "+dob);
			System.out.println("Address is: "+address);
			System.out.println("Gender is: "+gender);
			
			boolean status = new UserDAO().registerUser(name, email, 
					phone, dob, address, gender);
			
			if(status) {
				System.out.println("User Registered");
				response.sendRedirect("index.jsp");
			}
			else {
				System.out.println("Unsuccessful registration");
				response.sendRedirect("registration.jsp");
			}
			
		}
	}

}
