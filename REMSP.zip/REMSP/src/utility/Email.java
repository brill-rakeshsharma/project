package utility;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class Email {

	String from = "ebuddies2014@gmail.com";
	String to[];
	static String message;
	
	public Email() {
		
	}
	
	Email(String mess, String email) {
		
		String[] to = {email};
		this.message = mess;
		this.to = to;
		
		sendMail();
	}
	
	private int sendMail()
	{
		  int i = 0;
	      Properties properties = System.getProperties();
	      properties.put("mail.smtp.starttls.enable", "true"); 
	      properties.put("mail.smtp.host", "smtp.gmail.com");
	      properties.put("mail.smtp.ssl.trust", "smtp.gmail.com");    

	     
	      properties.put("mail.smtp.port", "587");
	      properties.put("mail.smtp.auth", "true");
	      Session session = Session.getInstance(properties, 
	    		    new javax.mail.Authenticator(){
	    		        protected PasswordAuthentication getPasswordAuthentication() {
	    		            return new PasswordAuthentication(
	    		                from, "ebuddies");// Specify the Username and the PassWord
	    		        }
	    		});
	      
		  
		  try{
		         final MimeMessage message = new MimeMessage(session);
		         message.setFrom(new InternetAddress(from));
		         InternetAddress[] addressTo = new InternetAddress[to.length];
		            for (int j = 0; j < to.length; j++)
		            {
		                addressTo[j] = new InternetAddress(to[j]);
		            }
		            message.setRecipients(Message.RecipientType.BCC, addressTo); 
		         message.setSubject("Email from EMS");
		         
				
		         message.setText(this.message);
		         //message.setContent(this.message,"text/html" );
		         
			    Transport.send(message);
				
		        System.out.println("Sent message successfully from admin....");
				session = null;
				 i = 1;
	        }
		   catch (MessagingException mex) 
		   {
	          mex.printStackTrace();
			  return i;
	       }
		   return i;
	}
	
	public void emailOtp(String email, String name, String otp) {
		System.out.println("At Email.java, In emailRamdomNo");
		
		String message = "Dear " + name + ", Your OTP for registration at EMS : " + otp;
		
		new Email(message, email);
	}
	
}
