package database;

import java.sql.*;
public class DBConnection {

	static Connection con = null;
	
	public static Connection getConnection() {
		
		try {
			
			String url = "jdbc:mysql://localhost:3306/remsp";
			String username = "root";
			String password = "root";
			
			Class.forName("com.mysql.jdbc.Driver");
			
			con = DriverManager.getConnection(url, username, password);
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return con;
	}
	
	public static void closeConnection(Connection con, Statement stmt,
			ResultSet res) {
		
		if (res != null) {
			try {
				res.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		if (stmt != null) {
			try {
				stmt.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		if (con != null) {
			try {
				con.close();

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
	}
	
}
