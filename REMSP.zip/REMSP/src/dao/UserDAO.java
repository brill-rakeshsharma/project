package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


import bean.UserBean;
import database.DBConnection;

public class UserDAO {

	Connection con = null;
	PreparedStatement ps = null;
	ResultSet rs = null;
	
	public UserBean login(String username) {
		
		UserBean user = null;
		
		try {
			
			String query = "select * from login join user where " +
					"login.username=user.email and login.username=?";
			
			con = DBConnection.getConnection();
			ps = con.prepareStatement(query);
			
			ps.setString(1, username);
			
			rs = ps.executeQuery();
			
			if(rs.next()) {
				
				user = new UserBean(rs.getString("id"), rs.getString("name"), 
						rs.getString("email"), rs.getString("phone"), 
						rs.getString("dob"), rs.getString("address"), 
						rs.getString("gender"));
				
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			DBConnection.closeConnection(con, ps, rs);
		}
		
		return user;
		
	}
	
	public boolean registerUser(String name, String email, String phone, 
			String dob, String address, String gender) {
		
		boolean status = false;
		PreparedStatement ps1 = null;
		
		try {
			
			String query = "insert into user(name, email, phone, "
					+ "dob, address, gender) values(?, ?, ?, ?, ?, ?)";
	  	  //  String query1 = "insert into login(email, password) values(?, ?)";
	  	    
	  	    String query1 = "insert into login(username) values(?)";
			
			
			
			con = DBConnection.getConnection();
			ps = con.prepareStatement(query);
			ps.setString(1, name);
			ps.setString(2,email);
			ps.setString(3, phone);
			ps.setString(4, dob);
			ps.setString(5, address);
			ps.setString(6, gender);
			
			
			
			int res = ps.executeUpdate();
			int res1 = 0;
			
			if(res != 0) {
				
				ps1 = con.prepareStatement(query1);
				ps1.setString(1,email);
			   // ps1.setString(2, password);
				res1 = ps1.executeUpdate();
			}
			
			
			
			if(res1 != 0)
				status = true;
			
		
		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			DBConnection.closeConnection(con, ps, rs);
		}
		
		return status;
	}
	
}
